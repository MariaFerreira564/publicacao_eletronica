import shelve
import re
from bs4 import BeautifulSoup as bs


def ext_titles():
	with open('portfolio.xml', 'r') as f:
		content = f.read()


		d = shelve.open('titles.db')
		ad = bs(content, 'xml') 

	for ensaio in ad.find_all('essay'):
		title = ensaio.title.text

		d[title] = title

		title = d[title]


	d.close()

ext_titles()



'''
so beautiful soup
index sai mas quando faço output nao'''
'''havera forma de so ter um bloco de codigo para cada elemento e fazer o numero do essay mudar'''



from bs4 import BeautifulSoup as bs

file = 'portfolio.xml'
with open (file) as f:
    d=f.read()

ad = bs(d, "xml")
n=1
  
for index in ad.find("portfolio"):

    I=f'<p><a href="ensaio1.html" target="_blank">{index.parent.essay1.title}</a></p>'
    I+=f'<p><a href="ensaio2.html" target="_blank">{index.parent.essay2.title}</a></p>'
    I+=f'<p><a href="ensaio3.html" target="_blank">{index.parent.essay3.title}</a></p>'
    I+=f'<p><a href="ensaio4.html" target="_blank">{index.parent.essay4.title}</a></p>'
I="<h1>PORTFOLIO ENSAIOS</h1>" + I
    
print(I)

'''with open(f'index.html', 'w') as f:
    f.write(I)'''

for ensaio in ad.find_all("essay1"):

    H=f'<h1>{ensaio.title.text}</h1>'
    H+=f'<p>{ensaio.parent.curricular_unit}</p>'
    H+=f'<p>{ensaio.parent.degree}</p>'
    H+=f'<p>{ensaio.student_name}</p>'
    H+=f'<p>{ensaio.parent.introduction}</p>'
    H+=f'<p>{ensaio.parent.body}</p>'
    H+=f'<p>{ensaio.parent.conclusion}</p>'

    with open(f'ensaio{n}.html', 'w') as f:
        f.write(H)

    n+=1
    
for ensaio in ad.find_all("essay2"):

    H=f'<h1>{ensaio.title.text}</h1>'
    H+=f'<p>{ensaio.parent.curricular_unit}</p>'
    H+=f'<p>{ensaio.parent.degree}</p>'
    H+=f'<p>{ensaio.student_name}</p>'
    H+=f'<p>{ensaio.parent.introduction}</p>'
    H+=f'<p>{ensaio.parent.body}</p>'
    H+=f'<p>{ensaio.parent.conclusion}</p>'

    with open(f'ensaio{n}.html', 'w') as f:
        f.write(H)

    n+=1
    
for ensaio in ad.find_all("essay3"):

    H=f'<h1>{ensaio.title.text}</h1>'
    H+=f'<p>{ensaio.parent.curricular_unit}</p>'
    H+=f'<p>{ensaio.parent.degree}</p>'
    H+=f'<p>{ensaio.student_name}</p>'
    H+=f'<p>{ensaio.parent.introduction}</p>'
    H+=f'<p>{ensaio.parent.body}</p>'
    H+=f'<p>{ensaio.parent.conclusion}</p>'

    with open(f'ensaio{n}.html', 'w') as f:
        f.write(H)

    n+=1

    
for ensaio in ad.find_all("essay4"):

    H=f'<h1>{ensaio.title.text}</h1>'
    H+=f'<p>{ensaio.parent.curricular_unit}</p>'
    H+=f'<p>{ensaio.parent.degree}</p>'
    H+=f'<p>{ensaio.student_name}</p>'
    H+=f'<p>{ensaio.parent.introduction}</p>'
    H+=f'<p>{ensaio.parent.body}</p>'
    H+=f'<p>{ensaio.parent.conclusion}</p>'

    with open(f'ensaio{n}.html', 'w') as f:
        f.write(H)

    n+=1



'''
lista index + beautiful soup
este apenas output files, o index fica branco
como por href de cada ensaio a mudar o numero'''


from re import *
from bs4 import BeautifulSoup as bs

with open('portfolio2.xml', 'r') as f:

    content=f.read()
    titles=[]

for title in findall(r'<title>(.*)</title>', content):
    titles.append(title)
    titles.sort()


def index(text):
    new_text = f'<p><a href="ensaio1.html" target="_blank">{text}</a></p>'
    return new_text

new_values = [index(items) for items in titles]
for i in new_values:
         print(i)

with open(f'index.html', 'w') as f:
    t="<h1>PORTFOLIO ENSAIOS</h1>" + i
    f.write(t)




with open ('portfolio2.xml') as f:
    d=f.read()

ad = bs(d, "xml")
n=1

for ensaio in ad.find_all("essay"):

    H=f'<h1>{ensaio.title.text}</h1>'
    H+=f'<p>{ensaio.parent.curricular_unit}</p>'
    H+=f'<p>{ensaio.parent.degree}</p>'
    H+=f'<p>{ensaio.student_name}</p>'
    H+=f'<p>{ensaio.parent.introduction}</p>'
    H+=f'<p>{ensaio.parent.body}</p>'
    H+=f'<p>{ensaio.parent.conclusion}</p>'

    with open(f'ensaio{n}.html', 'w') as f:
        f.write(H)

    n+=1
    
from bs4 import BeautifulSoup as bs

file = 'portfolio.xml'
with open (file) as f:
	d=f.read()

ad = bs(d, "xml")
n=1
  
for index in ad.find_all("title"):

	I=f'<p><a href="ensaio1.html" target="_blank">O uso da metáfora em cosméticos e automóveis</a></p>'
	I+=f'<p><a href="ensaio2.html" target="_blank">Hudson River School</a></p>'
	I+=f'<p><a href="ensaio3.html" target="_blank">Arabic women and their mischance</a></p>'
	I+=f'<p><a href="ensaio4.html" target="_blank">A cultura na Alemanha da era nacional-socialista</a></p>'
	I="<h1>PORTFOLIO ENSAIOS</h1>" + I

	with open(f'index.html', 'w') as f:
		f.write(I)

for ensaio in ad.find_all("essay"):

	H=f'<h1>{ensaio.title.text}</h1>'
	H+=f'<p>{ensaio.parent.curricular_unit}</p>'
	H+=f'<p>{ensaio.parent.degree}</p>'
	H+=f'<p>{ensaio.student_name}</p>'
	H+=f'<p>{ensaio.parent.introduction}</p>'
	H+=f'<p>{ensaio.parent.body}</p>'
	H+=f'<p>{ensaio.parent.conclusion}</p>'

	with open(f'ensaio{n}.html', 'w') as f:
		f.write(H)

	n+=1







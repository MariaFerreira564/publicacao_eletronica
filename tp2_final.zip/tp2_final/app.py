#!/usr/bin/python
from flask import Flask, render_template, request, send_file
from re import *
import json
import dbm
import requests
import shelve
from data import authors, intro, desc
import os 

app = Flask (__name__)

s = shelve.open('titles.db')


@app.route('/')
def indice():
    
    return render_template('index.html', title = f'Interface de navegação para ensaios dos alunos, Beatriz Freitas, Manuela Ferreira e Sérgio Pereira, do Mestrado em Humanidades Digitais, unidade curricular opcional, Publicação Eletrónica.')



@app.route('/essays')
def essays():
	
	return render_template('essays.html', title = 'Acesso aos ensaios, em formato pdf')



@app.route('/descriptions')
def descript():
	
	return render_template('description.html', title = 'Descrição Projeto', description = desc)



@app.route('/intros')
def introduction():
	
	return render_template('intro.html', title = 'Introduções de cada ensaio', intro = intro)



@app.route('/intros/<exp>')
def intros_exp(exp):
	res = [i for i in intro if search(exp,i)]
	
	return render_template('intro_search.html', title = rf'Introduções contendo {exp}', intro = res)



@app.route('/intros/new', methods=['POST'])
def intros_new():
	with open('novointro.txt', 'r') as f:
		linhas = f.readlines()
		linhas += intro
		novo_intro = request.form.get('title')

	with open('novointro.txt', 'a') as f:
		f.write(novo_intro)
		intro.append(novo_intro)

	return render_template('intro.html', title ='Introduções de cada ensaio', intro = intro)



@app.route('/titles')
def titulos():
	res = requests.get('http://localhost:5000/api/titles')
	data = json.loads(res.content)

	return render_template('titles.html', title = 'Lista de titulos', titles = data)



@app.route('/titles/new', methods=['POST'])
def titles_new():
	title = request.form.get('title')
	s[title] = title
	s.sync()
	data = list(s.keys())

	return render_template('titles.html', title='Lista de titulos', titles = data)



@app.route('/authors')
def autores():
	
	return render_template('author.html', title ='Lista de autores', authors = authors)



@app.route('/authors/novo', methods=['POST'])
def autor():
	with open('novoauthor.txt', 'r') as f:
		linhas = f.readlines()
		linhas += authors

		novo_autor = request.form.get('title')

	
	with open('novoauthor.txt', 'a') as f:
		f.write(novo_autor)
		authors.append(novo_autor)

	return render_template('author.html', title = 'Lista de autores', authors = authors)


#ROTAS PARA FICHEIROS EM PDF
@app.route('/johnkennedy.pdf')
def return_essay1():
	print(os.path.exists('templates/johnkennedy.pdf'))
	
	return send_file('templates/johnkennedy.pdf')


@app.route('/feminism.pdf')
def return_essay2():
	print(os.path.exists('templates/feminism.pdf'))
	
	return send_file('templates/feminism.pdf')


@app.route('/metacosmetica.pdf')
def return_essay3():
	print(os.path.exists('templates/metacosmetica.pdf'))
	
	return send_file('templates/metacosmetica.pdf')


@app.route('/nscultura.pdf')
def return_essay4():
	print(os.path.exists('templates/nscultura.pdf'))
	
	return send_file('templates/nscultura.pdf')


@app.route('/hrs.pdf')
def return_essay5():
	print(os.path.exists('templates/hrs.pdf'))
	
	return send_file('templates/hrs.pdf')


@app.route('/ca.pdf')
def return_essay6():
	print(os.path.exists('templates/ca.pdf'))
	
	return send_file('templates/ca.pdf')


@app.route('/tearsale.pdf')
def return_essay7():
	print(os.path.exists('templates/tearsale.pdf'))
	
	return send_file('templates/tearsale.pdf')

@app.route('/modernistss.pdf')
def return_essay8():
	print(os.path.exists('templates/modernistss.pdf'))
	
	return send_file('templates/modernistss.pdf')



#API
@app.route('/api/titles')
def api_essays():
    data = list(s.keys()) 
    
    return json.dumps(data)









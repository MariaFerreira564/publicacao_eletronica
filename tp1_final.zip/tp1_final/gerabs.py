from bs4 import BeautifulSoup as bs

file = 'portfolio.xml'
with open (file) as f:
    d=f.read()

ad = bs(d, "xml")
n=1
I='''<html><head>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="index.css">
    </head>
    <body>
<p><h1>Portfólio de Ensaios</h1></p>''' 
i=1
for ensaio in ad.find_all("essay"):
    '''encontrar títulos para criar index'''

    I+=f'<p><a href="ensaio{i}.html" target="_blank">{ensaio.title.text}</a></p>'
    i+=1
    
with open(f'index.html', 'w') as f:
    f.write(I)


 

for description in ad.find("portfolio"):
    '''encontrar descrição e membros da equipa para criar acesso'''

    d=f'<p><h3>{description.parent.desc}</h3></p>'
    d+=f'<p><h3>{description.parent.team}</h3></p>'
    
with open(f'acesso.html', 'w') as f:
    f.write('''<html><head>
    <meta charset="utf-8"/>
    <link rel="stylesheet" href="acesso.css">
    </head>
    <body>
<p><h1>Portfólio de Ensaios</h1></p>''')
    f.write(d)
    f.write(f'<p><center><a href="index.html" target="_blank">ACESSO PORTFÓLIO</a></center></p>')




for ensaio in ad.find_all("essay"):
    '''extrair ensaios'''
    H=f'<h1>{ensaio.title.text}</h1>'
    H+=f'<p><ul><li>{ensaio.curricular_unit}</ul></li></p>'
    H+=f'<p><ul><li>{ensaio.degree}</ul></li></p>'
    H+=f'<p><ul><li>{ensaio.student_name}</ul></li></p>'
    H+=f'<p><center>{ensaio.link}</center></p>'
    H+=f'<p>{ensaio.introduction}</p>'
    H+=f'<p>{ensaio.body}</p>'
    H+=f'<p>{ensaio.conclusion}</p>'

    with open(f'ensaio{n}.html', 'w') as f:
        f.write('''<html><head>
       <meta charset="utf-8"/>
        <link rel="stylesheet" href="ensaios.css">
        </head>
        <body>''')
        f.write(H)

    n+=1
    




